package com.tewvig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionMemoireApplicationTests {

	@Test
	void contextLoads() {
	}

}
