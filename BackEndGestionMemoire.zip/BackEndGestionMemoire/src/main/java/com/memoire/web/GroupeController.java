package com.memoire.web;

import com.memoire.entity.Groupe;
import com.memoire.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

public class GroupeController {
    @Autowired
    private AccountService accountService;


    @GetMapping("/groupes")
    public List<Groupe> getGroupes(){
        return accountService.getGroupes();
    }
}
