package com.memoire.web;

import com.memoire.dao.SujetRepository;
import com.memoire.entity.*;
import com.memoire.service.AccountService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EtudiantController {
    @Autowired

private AccountService accountService;
    @Autowired
    SujetRepository sujetRepository;
//        @PostMapping("/ProposeSujetParGrp")
//        public Sujet ProposeSujetParGrp(@RequestBody EtudiantForme etudiantForme){
//            return  accountService.ProposeSujetParGrp(etudiantForme.getTitreSujet(),
//                    etudiantForme.getNomEntreprice(),etudiantForme.getIdGrp());
//
//        }

    @GetMapping ("/EtudiantListeSujetPropose")
    public List<Sujet> ListeSujet(){
                return sujetRepository.findAll();
    }

    @GetMapping("/GroupeEtuduant/{matricule}")
    public Groupe getGroupe(@PathVariable String matricule) {
            Groupe etudiantGroupe = new Groupe() ;
        for (Groupe groupe :
                accountService.getGroupes()) {
            for (Etudiant etudiant1 :
                    groupe.getEtudiants()) {
                if (matricule.equals(etudiant1.getMatriculeetudiant())) {
                    etudiantGroupe = groupe;
                    break;
                }
            }
        }
        return etudiantGroupe;
    }
}

@Data
class  EtudiantForme {
    private  String titreSujet;
    private String nomEntreprice;
    private String idGrp;
}
