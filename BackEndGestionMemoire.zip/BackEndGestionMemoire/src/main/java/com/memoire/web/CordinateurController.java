package com.memoire.web;

import com.memoire.entity.Etudiant;
import com.memoire.entity.Groupe;
import com.memoire.entity.Sujet;
import com.memoire.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CordinateurController {
    @Autowired
    private AccountService accountService;
    @GetMapping("/sujetValider/{titreSujet}")
public Sujet ValiderSujet(@PathVariable String titreSujet) {
        return accountService.validerSujet(titreSujet);
    }

        @GetMapping("/RefuserSujet/{titreSujet}")
        public Sujet RefuserSujet(@PathVariable String titreSujet) {
            return accountService.RefuserSujet(titreSujet);
//    Sujet sujetValider = new Sujet() ;
//    for (Sujet sujet1 :
//            accountService.getSujets()) {
//
//        if (sujet1.getValider()==false)
//               sujet1.setValider(true);
//               sujet1.getCordinateur();
//        sujetValider =sujet1;
//
//
//
//    return sujetValider;

    }

}