package com.memoire.web;

import com.memoire.dao.EnsigniantRepository;
import com.memoire.dao.SujetRepository;
import com.memoire.entity.Sujet;
import com.memoire.service.AccountService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class EnsegniatController {
    @Autowired
    private AccountService accountService;
    @Autowired
    SujetRepository sujetRepository;
@Autowired
private EnsigniantRepository ensigniantRepository;
    @PostMapping("/ProposeSujetParEnseigniat")
    public Sujet ProposeSujetParGrp(@RequestBody EnseigniantForme enseigniantForme) {
        return accountService.ProposeSujetParEnseigniat(enseigniantForme.getTitreSujet(), enseigniantForme.getNomEnseigniant(), enseigniantForme.getNomEnseigniant());

    }

    @GetMapping("/EnseignantListeSujetPropose")
    public List<Sujet> ListeSujet() {
        return sujetRepository.findAll();
    }
//    @GetMapping("/nomEnseginat")
//    public String getNomEnsgniet(String nomEnseigniant) {
//        return ensigniantRepository.findByNomEnseigniant(nomEnseigniant);
//    }

    @Data
    class EnseigniantForme {
        private String titreSujet;
        private String nomEntreprice;
        private String nomEnseigniant;
    }

//    public Sujet ValiderSujet(@PathVariable String titreSujet, String nomEnseigniant) {
//        return accountService.validerSujet(titreSujet);
//    }

@GetMapping("/DemandeEncadrantSujet/{titreSujet}/{nomEnseigniant}")
  public Sujet DemandeEncadrantSujet(@PathVariable ("titreSujet")String titreSujet,@PathVariable("nomEnseigniant") String nomEnseigniant) {
      return accountService.DemandeEncadrantSujet(titreSujet, nomEnseigniant);
   }
    @GetMapping("/ValiderDemendeEncadrant/{titreSujet}")
    public Sujet ValiderDemendeEncadrant(@PathVariable ("titreSujet")String titreSujet) {
        return accountService.ValiderDemendeEncadrant(titreSujet);
    }
    @GetMapping("/RefuserDemendeEncadrant/{titreSujet}")
    public Sujet RefuserDemendeEncadrant(@PathVariable String titreSujet) {
        return accountService.RefuserDemendeEncadrant(titreSujet);
    }
//    @PostMapping("/DemandeEncadrantSujet")
//    public Sujet DemandeEncadrantSujet(@PathVariable String titreSujet ,
//                                       @RequestBody EnseigniantForme enseigniantForme) {
//        return accountService.DemandeEncadrantSujet(titreSujet,enseigniantForme.getNomEnseigniant());
//}

}


