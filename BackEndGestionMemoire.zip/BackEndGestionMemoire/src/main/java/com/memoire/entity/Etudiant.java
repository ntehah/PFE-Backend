package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Etudiant implements Serializable{
	@Id
	private String matriculeetudiant;
	private String nom;
	private String prenom;
	@ManyToOne
	private Groupe groupe;
//	@ManyToOne
//private Filliere filliere;
//@ManyToOne
//private Niveau niveau;
}
