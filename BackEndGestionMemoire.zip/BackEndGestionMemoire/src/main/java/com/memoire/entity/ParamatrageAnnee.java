package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Collection;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ParamatrageAnnee {
    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private  long id;

    private String anneeEncours;
  @OneToMany
    private Collection<Sujet> sujets;
    private int nbrEtudiantMin;
    private int nbrEtudiantMax;
    private  Date PeriodeValidationSujet;
    private  Date PeriodeSoutenace;

}
