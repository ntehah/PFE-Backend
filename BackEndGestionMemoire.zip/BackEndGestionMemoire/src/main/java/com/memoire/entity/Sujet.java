package com.memoire.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Sujet implements Serializable {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private  long id;
	@Column(unique = true)
	private String titreSujet;

	private Date dateHeures=new Date();
  
  private  String description;
  private  String resultatsattendus;
  private String competances;
  private Boolean valider;
	private Boolean DemendeEncadrant;
  private int nbrEtudiantMin;
  private  int nbrEtudiantMax;
	@ManyToOne
	@JoinColumn(name = "nomEnseignatProposer")
	private Ensigniant ensigniant;
	@OneToOne
	private Groupe groupe;
	@ManyToOne
	@JoinColumn(name = "AnneeEncours")
	private ParamatrageAnnee paramatrageAnnee;
@ManyToOne
@JoinColumn(name = "cordintereValider")
private Cordinateur cordinateur;
	@ManyToOne
	private Filliere fillieres;
@ManyToOne
//@JoinColumn(name = "superviseur")
private Superviseur superviseur;
	@ManyToOne
//	@JoinColumn(name = "entrepriseAcceuill")
	private Entreprise entreprise;

	@ManyToOne
	@JoinColumn(name = "Planning_soutenance")
   private PlanningSoutenance planningSoutenance_soutenance;

	@OneToMany
	private Collection <Fichier> fichiers = new ArrayList<>();
	@ManyToOne
//  @JoinColumn(name = "encad_acadimiquet")
private Ensigniant encad_acadimique;
	@ManyToOne
	@JoinColumn(name = "periodePropose")
	private  ParamatragePeriodePropose paramatragePeriodePropose;

	public Entreprise   getEntreprise(){
		return entreprise;
	}
	public   void setEntreprise( Entreprise entreprise){
		this.entreprise=entreprise;
	}
}
