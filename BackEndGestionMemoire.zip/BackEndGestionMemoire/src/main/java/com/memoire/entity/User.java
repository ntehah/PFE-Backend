package com.memoire.entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private  long id;
	@Column(unique = true,name = "Email")
	private String username ;
	@Column(unique = true,name = "Username")
	private String Email ;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String  password ;
	private Boolean actived;
	@ManyToMany(fetch = FetchType.EAGER)
	private Collection <Role> roles = new ArrayList<>();
   @OneToMany
	private  Collection<Etudiant> etudiants;
	@OneToMany
	private  Collection<Ensigniant> ensigniants;

}
