package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Filliere {
    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private  long id;
    private  String nomfilliere;
    private String Codefilliere;

    @OneToMany( mappedBy = "fillieres" ,fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Collection<Sujet> sujets = new ArrayList<>();
    @ManyToOne
    @JoinColumn(name = "cordinateur_filliere")
    private Cordinateur cordinateur;
    @OneToMany( mappedBy = "filliere" ,fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Collection<Groupe> groupes;
    @ManyToOne

    private Departement departement;

    private Date debutperiodeProposesujet ;
    private  Date finperiodeProposesujet ;
    @ManyToOne
    private PlanningSoutenance planningSoutenance;
    @ManyToOne
    private ParamatrageAnnee paramatrageAnnee;



}
