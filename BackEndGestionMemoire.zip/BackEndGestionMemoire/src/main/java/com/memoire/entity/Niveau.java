package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Collection;
import java.util.Date;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Niveau {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private  long id;
    private String nomNiveou;

    private String annee;
    @OneToMany(mappedBy = "niveau",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Collection<Groupe> groupes;
private String code;}
