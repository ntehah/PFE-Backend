package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Entreprise implements Serializable {
    @Id
    private String nomEntreprice;
    private String adresse;
    @OneToMany
    private Collection<Sujet> sujets;
}