package com.memoire.entity;

public interface SujetdetailleProjection {
}
