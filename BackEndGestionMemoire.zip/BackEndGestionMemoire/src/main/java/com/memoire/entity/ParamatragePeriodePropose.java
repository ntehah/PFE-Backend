package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Collection;
import java.util.Date;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ParamatragePeriodePropose {

  @Id @GeneratedValue(strategy = GenerationType.AUTO)
  private  long id;

    private  Date debutperiodeProposesujet ;
  private  Date finperiodeProposesujet ;
  @OneToMany
  private Collection<Filliere> fillieres;
    @OneToMany
    private Collection<Sujet> sujets;
}