package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Departement implements Serializable {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private  long id;
	private String nomDepartement;
	private  String codeDepartement;
	@OneToMany (mappedBy = "departement",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Collection<Ensigniant> ensigniantsapartient;
	@OneToMany
	private Collection<Filliere> fillieres;
}
