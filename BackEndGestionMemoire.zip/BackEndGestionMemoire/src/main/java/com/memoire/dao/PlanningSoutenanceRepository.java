package com.memoire.dao;

import com.memoire.entity.ParamatragePeriodePropose;
import com.memoire.entity.PlanningSoutenance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;

public interface  PlanningSoutenanceRepository extends JpaRepository<PlanningSoutenance, Long> {
    public PlanningSoutenance findByDateSoutence(Date dateSoutence);
}