package com.memoire.dao;

import com.memoire.entity.Filliere;
import com.memoire.entity.Niveau;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NiveouRepository extends JpaRepository<Niveau, Long> {
    public Niveau findByNomNiveou(String nomNiveou);
}
